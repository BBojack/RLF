"RLForest" <-
  function(x, ...)
    UseMethod("RLForest")
